package com.example.telegramadmin

import com.example.telegramadmin.telegram.model.IncomingMessage
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class TelegramUpdateParsingTest {

    @Test
    fun `parses a plain text message`() {
        val json = JSONObject(
            """
            {
              "update_id": 100,
              "message": {
                "chat": {"id": 555},
                "from": {"id": 555},
                "text": "/status"
              }
            }
            """.trimIndent()
        )

        val result = IncomingMessage.fromJson(json)

        assertEquals(100L, result?.updateId)
        assertEquals(555L, result?.chatId)
        assertEquals(555L, result?.fromId)
        assertEquals("/status", result?.text)
        assertNull(result?.documentFileId)
    }

    @Test
    fun `parses a document message with caption`() {
        val json = JSONObject(
            """
            {
              "update_id": 101,
              "message": {
                "chat": {"id": 555},
                "from": {"id": 555},
                "caption": "~/Download",
                "document": {"file_id": "ABC123", "file_name": "notes.txt"}
              }
            }
            """.trimIndent()
        )

        val result = IncomingMessage.fromJson(json)

        assertEquals("ABC123", result?.documentFileId)
        assertEquals("notes.txt", result?.documentFileName)
        assertEquals("~/Download", result?.caption)
    }

    @Test
    fun `returns null for updates with no message (e.g. edited_message, callback_query)` {
        val json = JSONObject(
            """{ "update_id": 102, "edited_message": {"chat": {"id": 1}} }"""
        )

        assertNull(IncomingMessage.fromJson(json))
    }

    @Test
    fun `returns null when update_id is missing`() {
        val json = JSONObject(
            """{ "message": {"chat": {"id": 1}, "text": "hi"} }"""
        )

        assertNull(IncomingMessage.fromJson(json))
    }
}
