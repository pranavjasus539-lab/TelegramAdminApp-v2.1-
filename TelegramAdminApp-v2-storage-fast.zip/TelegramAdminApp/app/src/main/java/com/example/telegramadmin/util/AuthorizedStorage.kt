package com.example.telegramadmin.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile

/** SAF-backed storage roots explicitly granted by the user. */
object AuthorizedStorage {
    private const val PREFS = "authorized_storage"
    private const val KEY_URIS = "tree_uris"

    data class Resolved(val file: DocumentFile, val displayPath: String)

    fun addTree(context: Context, uri: Uri) {
        context.contentResolver.takePersistableUriPermission(
            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        val set = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_URIS, emptySet()).orEmpty().toMutableSet()
        set.add(uri.toString())
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putStringSet(KEY_URIS, set).apply()
    }

    fun roots(context: Context): List<Uri> = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getStringSet(KEY_URIS, emptySet()).orEmpty().mapNotNull { runCatching { Uri.parse(it) }.getOrNull() }

    /** Resolves an absolute shared-storage path only if it lies under a user-granted SAF tree. */
    fun resolve(context: Context, rawPath: String): Resolved? {
        val path = normalize(rawPath) ?: return null
        val wanted = path.removePrefix("/storage/emulated/0").trim('/').split('/').filter { it.isNotBlank() }
        for (uri in roots(context)) {
            val grantedRoot = treeRelativePath(uri) ?: continue
            val granted = grantedRoot.split('/').filter { it.isNotBlank() }
            if (wanted.size < granted.size || wanted.take(granted.size) != granted) continue
            val root = DocumentFile.fromTreeUri(context, uri) ?: continue
            var current = root
            var ok = true
            for (segment in wanted.drop(granted.size)) {
                if (segment == "." || segment == ".." || segment.contains('\u0000')) { ok = false; break }
                current = current.findFile(segment) ?: run { ok = false; break }
            }
            if (ok) return Resolved(current, path)
        }
        return null
    }

    /** Human-readable list of the roots the user has granted. */
    fun describeRoots(context: Context): List<String> = roots(context).mapNotNull { uri ->
        treeRelativePath(uri)?.let { if (it.isBlank()) "/storage/emulated/0" else "/storage/emulated/0/$it" }
    }

    private fun treeRelativePath(uri: Uri): String? {
        val id = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrNull() ?: return null
        if (id.startsWith("primary:")) return id.removePrefix("primary:").trim('/')
        return null // Other storage providers are deliberately not guessed into shared-storage paths.
    }

    private fun normalize(raw: String): String? {
        var value = raw.trim()
        if (value.isEmpty() || value == "~") return "/storage/emulated/0"
        if (value.startsWith("~/")) value = "/storage/emulated/0/${value.removePrefix("~/")}" else if (!value.startsWith('/')) value = "/storage/emulated/0/$value"
        val out = ArrayDeque<String>()
        for (part in value.split('/')) {
            when {
                part.isEmpty() || part == "." -> Unit
                part == ".." -> if (out.isNotEmpty()) out.removeLast() else return null
                part.contains('\u0000') -> return null
                else -> out.addLast(part)
            }
        }
        val result = "/" + out.joinToString("/")
        return if (result == "/storage/emulated/0" || result.startsWith("/storage/emulated/0/")) result else null
    }
}
