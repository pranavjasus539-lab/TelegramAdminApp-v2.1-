package com.example.telegramadmin.ui

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.provider.DocumentsContract
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.telegramadmin.AdminApp
import com.example.telegramadmin.R
import com.example.telegramadmin.admin.AdminReceiver
import com.example.telegramadmin.config.ConfigException
import com.example.telegramadmin.databinding.ActivityMainBinding
import com.example.telegramadmin.service.BotForegroundService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var app: AdminApp

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        app = application as AdminApp

        requestNotificationPermissionIfNeeded()
        loadCurrentConfig()
        refreshStatusText()

        binding.saveButton.setOnClickListener { onSaveClicked() }
        binding.startButton.setOnClickListener { startBotService() }
        binding.stopButton.setOnClickListener { stopBotService() }
        binding.grantStorageButton.setOnClickListener { requestFolderAccess() }
        binding.grantAllFilesButton.setOnClickListener { requestAllFilesAccess() }
        binding.grantLocationButton.setOnClickListener { requestLocationPermission() }

        if (intent?.getBooleanExtra(EXTRA_AUTOSTART_SERVICE, false) == true) {
            startBotService()
        }
    }

    private fun loadCurrentConfig() {
        val config = app.configManager.load()
        binding.botTokenInput.setText(config.botToken)
        if (config.ownerId != 0L) {
            binding.ownerIdInput.setText(config.ownerId.toString())
        }
    }

    private fun onSaveClicked() {
        val token = binding.botTokenInput.text?.toString()?.trim().orEmpty()
        val ownerIdText = binding.ownerIdInput.text?.toString()?.trim().orEmpty()
        val ownerId = ownerIdText.toLongOrNull()

        if (token.isEmpty() || ownerId == null) {
            toast("Enter both a bot token and a numeric owner chat ID.")
            return
        }

        try {
            app.configManager.save(token, ownerId)
            toast("Saved. Tap \"Start service\" to connect.")
        } catch (e: ConfigException) {
            toast("Could not save config: ${e.message}")
        }
    }

    private fun startBotService() {
        val config = app.configManager.load()
        if (!config.isValid) {
            toast("Save a bot token and owner ID first.")
            return
        }
        val intent = Intent(this, BotForegroundService::class.java)
        ContextCompat.startForegroundService(this, intent)
        refreshStatusText()
        toast("Starting…")
    }

    private fun stopBotService() {
        stopService(Intent(this, BotForegroundService::class.java))
        refreshStatusText()
    }

    private fun refreshStatusText() {
        binding.statusText.text = getString(R.string.status_idle)
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
    }

    /** Opens Android's system "All files access" settings for this app. */
    private fun requestAllFilesAccess() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) {
            toast("This Android version already allows shared-storage access.")
            return
        }
        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
            data = Uri.parse("package:$packageName")
        }
        startActivity(intent)
    }

    /** Opens Android's system folder picker. The user explicitly chooses which folder the bot may access. */
    private fun requestFolderAccess() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION)
            putExtra("android.content.extra.SHOW_ADVANCED", true)
        }
        startActivityForResult(intent, REQUEST_FOLDER_ACCESS)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_FOLDER_ACCESS && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            runCatching {
                com.example.telegramadmin.util.AuthorizedStorage.addTree(this, uri)
                toast("Folder access granted. You can now use /ls, /get, uploads, /delete, /mkdir and /rename for that folder.")
            }.onFailure { toast("Could not save folder permission: ${it.message}") }
        }
    }

    private fun requestLocationPermission() {
        val hasFine = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!hasFine) {
            // Step 1: foreground location must be granted before Android allows requesting
            // background location at all.
            requestPermissions(
                arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION),
                2
            )
            return
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            toast("Already granted.")
            return
        }

        val hasBackground = ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_BACKGROUND_LOCATION) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        if (hasBackground) {
            toast("Already granted, including background access.")
            return
        }

        // Android 10+ requires background location to be requested as its own step, and on
        // Android 11+ it can only be granted from system Settings, not a normal dialog.
        if (Build.VERSION.SDK_INT == Build.VERSION_CODES.Q) {
            requestPermissions(arrayOf(android.Manifest.permission.ACCESS_BACKGROUND_LOCATION), 3)
        } else {
            toast("Now choose \"Allow all the time\" on the next screen so /location works while the app is in the background.")
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
            }
            startActivity(intent)
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    companion object {
        const val EXTRA_AUTOSTART_SERVICE = "autostart_service"
        private const val REQUEST_FOLDER_ACCESS = 40

        /** Used only by the README's optional Device Owner setup instructions - exposed here so
         * that flow has a stable ComponentName to reference from adb. */
        fun deviceAdminComponent(activity: MainActivity): ComponentName =
            ComponentName(activity, AdminReceiver::class.java)
    }
}
