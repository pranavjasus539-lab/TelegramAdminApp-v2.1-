package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.util.AuthorizedStorage

class ListFilesCommand : Command {
    override val name = "ls"
    override val description =
        "List shared storage or an authorized folder, e.g. /ls /storage/emulated/0/Download"

    override suspend fun execute(ctx: CommandContext): String {
        val requestedPath = ctx.args.trim()

        // With All files access, default to the shared-storage root. Otherwise
        // fall back to the first folder explicitly authorized through SAF.
        val raw = if (requestedPath.isBlank()) {
            if (com.example.telegramadmin.util.FileAccess.canAccessAllFiles()) {
                "/storage/emulated/0"
            } else {
                AuthorizedStorage.describeRoots(ctx.appContext).firstOrNull()
                    ?: return "❌ No storage access is enabled.\nOpen the app and grant All files access or choose a folder with Grant Folder Access."
            }
        } else requestedPath

        val resolved = AuthorizedStorage.resolve(ctx.appContext, raw)
            ?: return "❌ Folder is not inside a user-authorized storage root.\n" +
                "Use /grant in the app to authorize a folder."

        if (!resolved.file.exists()) return "❌ Not found: ${resolved.displayPath}"
        if (!resolved.file.isDirectory) return "❌ Not a folder: ${resolved.displayPath}"

        val entries = resolved.file.listFiles()
            .sortedWith(compareBy({ !it.isDirectory }, { it.name?.lowercase().orEmpty() }))

        if (entries.isEmpty()) return "📁 ${resolved.displayPath}\n(empty)"

        return "📁 ${resolved.displayPath}\n" + entries.joinToString("\n") { file ->
            val marker = if (file.isDirectory) "📁" else "📄"
            val size = if (file.isFile) " (${file.length() / 1024} KB)" else ""
            "$marker ${file.name.orEmpty()}$size"
        }
    }
}
