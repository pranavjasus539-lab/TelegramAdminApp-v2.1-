package com.example.telegramadmin.commands.impl

import android.content.pm.ApplicationInfo
import android.os.Environment
import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import java.io.File

/** Lists installed applications and only their externally accessible/shared-storage data.
 * Private /data/user/0 app sandboxes are intentionally not accessed. */
class AppManagerCommand : Command {
    override val name = "apps"
    override val description = "List installed apps and inspect accessible external app storage with /appstorage <package>"

    override suspend fun execute(ctx: CommandContext): String {
        val pm = ctx.appContext.packageManager
        val apps = pm.getInstalledApplications(0)
            .filter { it.packageName != ctx.appContext.packageName }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }

        if (apps.isEmpty()) return "📱 No other installed apps found."

        return buildString {
            append("📱 Installed apps (${apps.size})\n")
            apps.forEach { app ->
                val label = pm.getApplicationLabel(app).toString()
                val mediaDir = File(Environment.getExternalStorageDirectory(), "Android/media/${app.packageName}")
                val media = if (mediaDir.isDirectory) " • media✓" else ""
                append("• $label\n  ${app.packageName}$media\n")
            }
        }.trimEnd()
    }
}

class AppStorageCommand : Command {
    override val name = "appstorage"
    override val description = "List externally accessible storage for an installed app: /appstorage <package>"

    override suspend fun execute(ctx: CommandContext): String {
        val pkg = ctx.args.trim()
        if (pkg.isBlank()) return "Usage: /appstorage <package>\nExample: /appstorage com.example.app"

        val pm = ctx.appContext.packageManager
        val app = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull()
            ?: return "❌ App not installed: $pkg"

        val label = pm.getApplicationLabel(app)
        val root = Environment.getExternalStorageDirectory()
        val candidates = listOf(
            File(root, "Android/media/$pkg"),
            File(root, "Android/data/$pkg")
        )

        val visible = candidates.filter { it.exists() && it.canRead() }
        if (visible.isEmpty()) {
            return "📱 $label\nPackage: $pkg\n\nNo externally accessible app-storage directory was found. Android may restrict Android/data on this device."
        }

        return buildString {
            append("📱 $label\nPackage: $pkg\n")
            visible.forEach { dir ->
                append("\n📁 ${dir.path}\n")
                val children = runCatching { dir.listFiles()?.toList().orEmpty() }
                    .getOrDefault(emptyList())
                    .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
                if (children.isEmpty()) append("(empty or restricted)\n")
                else children.take(200).forEach { f ->
                    append(if (f.isDirectory) "📁" else "📄")
                    append(" ${f.name}")
                    if (f.isFile) append(" (${f.length() / 1024} KB)")
                    append("\n")
                }
                if (children.size > 200) append("… ${children.size - 200} more entries\n")
            }
        }.trimEnd()
    }
}
