package com.example.telegramadmin.commands

import android.os.Environment
import com.example.telegramadmin.telegram.TelegramApiException
import com.example.telegramadmin.util.AuthorizedStorage
import java.io.File

/** Handles owner-sent Telegram documents and saves them only inside a user-authorized SAF root. */
object IncomingFileHandler {
    suspend fun handle(ctx: CommandContext): String {
        val fileId = ctx.message.documentFileId ?: return "❌ No file found in that message."
        val fileName = sanitizeName(ctx.message.documentFileName ?: "file_${System.currentTimeMillis()}")
        val requestedDir = ctx.message.caption?.trim().orEmpty().ifBlank {
            "/storage/emulated/0/Download/TelegramAdmin"
        }
        val dir = AuthorizedStorage.resolve(ctx.appContext, requestedDir)
            ?: return "❌ Destination is not inside a user-authorized folder. Use the app's Grant Folder Access first."
        if (!dir.file.isDirectory) return "❌ Destination is not a folder: ${dir.displayPath}"

        return try {
            val existing = dir.file.findFile(fileName)
            if (existing != null) return "❌ A file named $fileName already exists. Rename it before uploading."
            val target = dir.file.createFile("application/octet-stream", fileName)
                ?: return "❌ Android could not create the destination file."
            val filePath = ctx.client.getFilePath(fileId)
            val temp = File.createTempFile("telegram_upload_", ".part", ctx.appContext.cacheDir)
            try {
                ctx.client.downloadFile(filePath, temp)
                ctx.appContext.contentResolver.openOutputStream(target.uri)?.use { out ->
                    temp.inputStream().use { input -> input.copyTo(out) }
                } ?: throw IllegalStateException("Could not open destination")
            } finally { temp.delete() }
            "✅ Saved to ${dir.displayPath}/$fileName"
        } catch (e: TelegramApiException) {
            "❌ Download failed: ${e.message}"
        } catch (e: Exception) {
            "❌ Could not save file: ${e.message}"
        }
    }

    private fun sanitizeName(name: String): String {
        val clean = name.substringAfterLast('/').substringAfterLast('\\').replace("\u0000", "_").trim()
        return clean.ifBlank { "file_${System.currentTimeMillis()}" }.take(180)
    }
}
