package com.example.telegramadmin.media

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.example.telegramadmin.R

object MediaCaptureRequest {
    private const val CHANNEL_ID = "media_capture_requests"
    private const val NOTIFICATION_ID = 42

    fun request(context: Context, chatId: Long, mode: String) {
        CaptureRequestStore.put(context, chatId, mode)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    "Media capture requests",
                    NotificationManager.IMPORTANCE_HIGH
                )
            )
        }

        val intent = Intent(context, CaptureActivity::class.java)
        val pending = PendingIntent.getActivity(
            context,
            mode.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val label = when (mode) {
            CaptureRequestStore.MODE_FRONT -> "front camera"
            CaptureRequestStore.MODE_BACK -> "back camera"
            else -> "microphone"
        }
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Telegram Admin: media request")
            .setContentText("Tap to approve and start the $label capture")
            .setStyle(NotificationCompat.BigTextStyle().bigText(
                "A Telegram command requested $label access. Nothing is captured until you open this notification and approve Android's permission prompt."
            ))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        manager.notify(NOTIFICATION_ID, notification)
    }
}
