package com.example.telegramadmin.media

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.core.content.ContextCompat
import com.example.telegramadmin.AdminApp
import java.io.File

/** User-visible capture screen. Remote Telegram commands can request a capture, but Android
 * permissions and a physical user tap are always required. No hidden/background recording. */
class CaptureActivity : AppCompatActivity() {
    private var request: Pair<Long, String>? = null
    private var recorder: MediaRecorder? = null
    private var audioFile: File? = null
    private val handler = Handler(Looper.getMainLooper())

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.all { it }) {
            startRequestedCapture()
        } else {
            Toast.makeText(this, "Permission denied; no capture was made.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        request = CaptureRequestStore.get(this)
        val mode = request?.second
        if (request == null || mode == null) {
            finish(); return
        }
        buildUi(mode)
    }

    private fun buildUi(mode: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        root.addView(TextView(this).apply {
            textSize = 22f
            text = "Telegram Admin — ${mode.uppercase()} capture"
        })
        root.addView(TextView(this).apply {
            text = "Capture is OFF until you press Start. Android will ask for permission."
            setPadding(0, 20, 0, 20)
        })
        root.addView(Button(this).apply {
            text = "Start capture"
            setOnClickListener { requestPermissionsForMode(mode) }
        })
        root.addView(Button(this).apply {
            text = "Cancel"
            setOnClickListener { CaptureRequestStore.clear(this@CaptureActivity); finish() }
        })
        setContentView(root)
    }

    private fun requestPermissionsForMode(mode: String) {
        val permissions = when (mode) {
            CaptureRequestStore.MODE_MIC -> arrayOf(Manifest.permission.RECORD_AUDIO)
            else -> arrayOf(Manifest.permission.CAMERA)
        }
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startRequestedCapture() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun startRequestedCapture() {
        val req = request ?: return
        when (req.second) {
            CaptureRequestStore.MODE_FRONT -> captureCamera(android.hardware.camera2.CameraCharacteristics.LENS_FACING_FRONT, req.first)
            CaptureRequestStore.MODE_BACK -> captureCamera(android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK, req.first)
            CaptureRequestStore.MODE_MIC -> recordMicrophone(req.first)
        }
    }

    private fun captureCamera(facing: Int, chatId: Long) {
        Toast.makeText(this, "Capturing photo…", Toast.LENGTH_SHORT).show()
        CameraCapture(this).takePhoto(facing) { result ->
            runOnUiThread {
                result.onSuccess { file ->
                    lifecycleScope.launch(Dispatchers.IO) {
                        val config = (application as AdminApp).configManager.load()
                        val sent = if (config.isValid) runCatching {
                            (application as AdminApp).telegramClient(config.botToken)
                                .sendPhoto(chatId, file, "User-approved camera capture")
                        }.isSuccess else false
                        file.delete()
                        runOnUiThread {
                            Toast.makeText(this@CaptureActivity, if (sent) "Photo sent" else "Photo could not be sent", Toast.LENGTH_LONG).show()
                            CaptureRequestStore.clear(this@CaptureActivity)
                            finish()
                        }
                    }
                }.onFailure { e -> Toast.makeText(this, "Camera failed: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun recordMicrophone(chatId: Long) {
        val file = File(cacheDir, "audio_${System.currentTimeMillis()}.m4a")
        audioFile = file
        try {
            recorder = MediaRecorder(this).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setOutputFile(file.absolutePath)
                prepare(); start()
            }
            Toast.makeText(this, "Recording for up to 30 seconds. Tap Stop when finished.", Toast.LENGTH_LONG).show()
            handler.postDelayed({ stopRecording(chatId) }, 30_000)
        } catch (e: Exception) {
            Toast.makeText(this, "Microphone failed: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun stopRecording(chatId: Long) {
        val r = recorder ?: return
        runCatching { r.stop() }
        r.release(); recorder = null
        val file = audioFile ?: return
        lifecycleScope.launch(Dispatchers.IO) {
            val config = (application as AdminApp).configManager.load()
            val sent = if (config.isValid) runCatching {
                (application as AdminApp).telegramClient(config.botToken)
                    .sendAudio(chatId, file, "User-approved microphone recording")
            }.isSuccess else false
            file.delete()
            runOnUiThread {
                Toast.makeText(this@CaptureActivity, if (sent) "Recording sent" else "Recording could not be sent", Toast.LENGTH_LONG).show()
                CaptureRequestStore.clear(this@CaptureActivity)
                finish()
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        recorder?.let { runCatching { it.stop() }; it.release() }
        recorder = null
        super.onDestroy()
    }
}
