package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.util.AuthorizedStorage

class GrantStorageCommand : Command {
    override val name = "grant"
    override val description = "Show folders explicitly authorized from the phone app"

    override suspend fun execute(ctx: CommandContext): String {
        val roots = AuthorizedStorage.describeRoots(ctx.appContext)
        return if (roots.isEmpty()) {
            "📁 No storage folders are authorized yet. Open Telegram Admin on the phone and tap \"Grant Folder Access\", then choose a folder."
        } else {
            "🔐 Authorized storage roots:\n" + roots.joinToString("\n") { "• $it" }
        }
    }
}
