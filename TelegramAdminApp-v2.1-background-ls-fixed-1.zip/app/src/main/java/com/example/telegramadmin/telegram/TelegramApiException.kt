package com.example.telegramadmin.telegram

/** Wraps any failure talking to the Telegram Bot API: HTTP errors, malformed JSON, timeouts. */
class TelegramApiException(message: String, cause: Throwable? = null) : Exception(message, cause)
