package com.example.telegramadmin.commands.impl

import android.content.ActivityNotFoundException
import android.content.Intent
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.util.FileAccess

/**
 * "Opening" a file with no one looking at the screen means launching whatever app handles that
 * file type, in a new task. If the phone is locked or no app claims the mime type, this will
 * fail gracefully and say so - it can't force the screen on or bypass the lock screen.
 */
class OpenFileCommand : Command {
    override val name = "open"
    override val description = "Open a file with its default app, e.g. /open ~/Download/report.pdf"

    override suspend fun execute(ctx: CommandContext): String {
        if (ctx.args.isBlank()) return "Usage: /open <path>"
        if (!FileAccess.canAccessAllFiles()) {
            return "⚠️ Storage permission not granted yet. Open the app and tap " +
                "\"Grant All files access\", then try again."
        }

        val file = FileAccess.resolve(ctx.args)
        if (!file.exists() || !file.isFile) return "❌ File not found: ${file.path}"

        return try {
            val context = ctx.appContext
            val uri = FileProvider.getUriForFile(
                context, "${context.packageName}.fileprovider", file
            )
            val extension = MimeTypeMap.getFileExtensionFromUrl(file.name)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
                ?: "*/*"

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
            "📂 Opening ${file.name}…"
        } catch (e: ActivityNotFoundException) {
            "❌ No app on this device can open that file type."
        } catch (e: Exception) {
            "❌ Could not open file: ${e.message}"
        }
    }
}
