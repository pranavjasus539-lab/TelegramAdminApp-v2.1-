package com.example.telegramadmin.commands.impl

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.ui.MainActivity
import kotlinx.coroutines.delay

/**
 * Android has no public "restart my own app" API. The standard workaround - schedule a launch
 * of the main activity a moment in the future, then kill this process - is what's used here.
 * The service's boot/restart wiring (START_STICKY, see BotForegroundService) then brings the
 * bot connection back up as part of normal app startup.
 */
class RestartAppCommand : Command {
    override val name = "restart"
    override val description = "Restart the app process"

    override suspend fun execute(ctx: CommandContext): String {
        ctx.client.sendMessage(ctx.message.chatId, "🔄 Restarting…")
        val context = ctx.appContext

        val restartIntent = Intent(context, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            putExtra(MainActivity.EXTRA_AUTOSTART_SERVICE, true)
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, restartIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_CANCEL_CURRENT
        )
        val alarmManager = context.getSystemService(android.content.Context.ALARM_SERVICE) as AlarmManager
        alarmManager.set(AlarmManager.RTC, System.currentTimeMillis() + 1500, pendingIntent)

        // Give the outgoing message a moment to actually reach Telegram before we die.
        delay(500)
        android.os.Process.killProcess(android.os.Process.myPid())
        return "" // unreachable, but required by the interface
    }
}
