package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.util.AuthorizedStorage

class MakeDirectoryCommand : Command {
    override val name = "mkdir"
    override val description = "Create a folder inside an authorized folder"

    override suspend fun execute(ctx: CommandContext): String {
        if (ctx.args.isBlank()) return "Usage: /mkdir <folder path>"
        val raw = ctx.args.trimEnd('/')
        val parentPath = raw.substringBeforeLast('/', missingDelimiterValue = "")
            .ifBlank { "/storage/emulated/0" }
        val name = raw.substringAfterLast('/').trim()
        if (name.isBlank() || name == "." || name == ".." || name.contains('\u0000')) return "❌ Invalid folder name."
        val parent = AuthorizedStorage.resolve(ctx.appContext, parentPath)
            ?: return "❌ Parent is not inside a user-authorized storage root."
        if (!parent.file.isDirectory) return "❌ Parent is not a folder."
        if (parent.file.findFile(name) != null) return "❌ Already exists: $name"
        return if (parent.file.createDirectory(name) != null) "✅ Created $raw" else "❌ Could not create folder."
    }
}
