package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.media.CaptureRequestStore
import com.example.telegramadmin.media.MediaCaptureRequest

class MicrophoneCommand : Command {
    override val name = "mic"
    override val description = "Request a user-approved microphone recording (up to 30 seconds)."

    override suspend fun execute(ctx: CommandContext): String {
        MediaCaptureRequest.request(ctx.appContext, ctx.message.chatId, CaptureRequestStore.MODE_MIC)
        return "📱 Approval required on the phone. Tap the media-capture notification, then approve Android's permission and start the capture. Nothing is captured silently."
    }
}
