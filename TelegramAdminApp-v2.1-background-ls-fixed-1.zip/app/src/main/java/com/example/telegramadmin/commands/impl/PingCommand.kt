package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext

class PingCommand : Command {
    override val name = "ping"
    override val description = "Check the app/service is running, with uptime"

    override suspend fun execute(ctx: CommandContext): String {
        val uptimeMs = System.currentTimeMillis() - ctx.serviceStartedAtMillis
        val minutes = uptimeMs / 60000
        val hours = minutes / 60
        return "✅ Running. Uptime: ${hours}h ${minutes % 60}m"
    }
}
