package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.util.AuthorizedStorage

class ListFilesCommand : Command {
    override val name = "ls"
    override val description =
        "List an authorized folder, e.g. /ls /storage/emulated/0/Download"

    override suspend fun execute(ctx: CommandContext): String {
        val requestedPath = ctx.args.trim()

        // With no argument, list the first folder explicitly authorized by
        // the user instead of the inaccessible shared-storage root.
        val raw = if (requestedPath.isBlank()) {
            AuthorizedStorage.describeRoots(ctx.appContext).firstOrNull()
                ?: return "❌ No storage folder is authorized.\nUse Grant Folder Access in the app first."
        } else {
            requestedPath
        }

        val resolved = AuthorizedStorage.resolve(ctx.appContext, raw)
            ?: return "❌ Folder is not inside a user-authorized storage root.\n" +
                "Use /grant in the app to authorize a folder."

        if (!resolved.file.exists()) return "❌ Not found: ${resolved.displayPath}"
        if (!resolved.file.isDirectory) return "❌ Not a folder: ${resolved.displayPath}"

        val entries = resolved.file.listFiles()
            .sortedWith(compareBy({ !it.isDirectory }, { it.name?.lowercase().orEmpty() }))

        if (entries.isEmpty()) return "📁 ${resolved.displayPath}\n(empty)"

        return "📁 ${resolved.displayPath}\n" + entries.joinToString("\n") { file ->
            val marker = if (file.isDirectory) "📁" else "📄"
            val size = if (file.isFile) " (${file.length() / 1024} KB)" else ""
            "$marker ${file.name.orEmpty()}$size"
        }
    }
}
