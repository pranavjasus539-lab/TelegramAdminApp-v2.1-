package com.example.telegramadmin.commands.impl

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import com.example.telegramadmin.admin.AdminReceiver
import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext

class RebootDeviceCommand : Command {
    override val name = "reboot"
    override val description = "Reboot the whole device (requires Device Owner setup, see README)"

    override suspend fun execute(ctx: CommandContext): String {
        val context = ctx.appContext
        val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val adminComponent = ComponentName(context, AdminReceiver::class.java)

        if (!dpm.isDeviceOwnerApp(context.packageName)) {
            return "❌ Not available: this app isn't set up as Device Owner, and a regular " +
                "app can't reboot the device without root. See the README for the optional " +
                "one-time ADB provisioning step. /restart still works for the app itself."
        }

        return try {
            ctx.client.sendMessage(ctx.message.chatId, "🔁 Rebooting device…")
            dpm.reboot(adminComponent)
            "" // device is rebooting; nothing more to say
        } catch (e: IllegalStateException) {
            "❌ Reboot refused, likely an active phone call: ${e.message}"
        } catch (e: Exception) {
            "❌ Reboot failed: ${e.message}"
        }
    }
}
