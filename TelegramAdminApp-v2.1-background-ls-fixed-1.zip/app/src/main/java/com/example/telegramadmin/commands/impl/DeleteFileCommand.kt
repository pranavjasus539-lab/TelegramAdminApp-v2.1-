package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.util.AuthorizedStorage

class DeleteFileCommand : Command {
    override val name = "delete"
    override val description = "Delete an authorized file or empty folder"

    override suspend fun execute(ctx: CommandContext): String {
        if (ctx.args.isBlank()) return "Usage: /delete <path>"
        val resolved = AuthorizedStorage.resolve(ctx.appContext, ctx.args)
            ?: return "❌ Path is not inside a user-authorized storage root."
        if (!resolved.file.exists()) return "❌ Not found: ${resolved.displayPath}"
        return if (resolved.file.delete()) "🗑️ Deleted ${resolved.displayPath}" else "❌ Delete failed: ${resolved.displayPath}"
    }
}
