package com.example.telegramadmin.media

import android.content.Context

/** Stores a pending, user-approved capture request. A request is only consumed by the
 * CaptureActivity after the user taps the notification. */
object CaptureRequestStore {
    private const val PREFS = "media_capture_request"
    private const val KEY_CHAT_ID = "chat_id"
    private const val KEY_MODE = "mode"

    const val MODE_FRONT = "front"
    const val MODE_BACK = "back"
    const val MODE_MIC = "mic"

    fun put(context: Context, chatId: Long, mode: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong(KEY_CHAT_ID, chatId)
            .putString(KEY_MODE, mode)
            .apply()
    }

    fun get(context: Context): Pair<Long, String>? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val id = p.getLong(KEY_CHAT_ID, Long.MIN_VALUE)
        val mode = p.getString(KEY_MODE, null) ?: return null
        if (id == Long.MIN_VALUE) return null
        return id to mode
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
