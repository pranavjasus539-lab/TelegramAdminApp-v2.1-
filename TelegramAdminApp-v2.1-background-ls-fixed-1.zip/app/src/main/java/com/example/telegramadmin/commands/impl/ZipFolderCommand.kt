package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.telegram.TelegramApiException
import com.example.telegramadmin.util.AuthorizedStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Creates ZIP parts and sends them to Telegram.
 *
 * Performance strategy:
 *  - Uses ZIP STORED entries (no DEFLATE compression). This avoids spending CPU trying to
 *    compress files such as JPG/PNG/MP4/APK/ZIP that are already compressed.
 *  - Pipelines work: while part N is uploading, part N+1 is prepared on a background IO worker.
 *  - Keeps only one prefetched ZIP at a time so storage/CPU usage stays bounded.
 *
 * STORED ZIP entries require their size and CRC32 before the entry is written, so each source
 * file is read once to calculate CRC32 and once to copy into the archive. This is the trade-off
 * for producing a true uncompressed (STORED) ZIP with java.util.zip.
 */
class ZipFolderCommand : Command {
    override val name = "zip"
    override val description = "Zip an authorized folder without compression and send it in pipelined parts, e.g. /zip /storage/emulated/0/Pictures"

    private val maxPartSize = 45L * 1024 * 1024

    override suspend fun execute(ctx: CommandContext): String = coroutineScope {
        if (ctx.args.isBlank()) return@coroutineScope "Usage: /zip <folder path>"

        val resolved = AuthorizedStorage.resolve(ctx.appContext, ctx.args.trim())
            ?: return@coroutineScope "❌ Folder is not inside a user-authorized storage root.\nUse /grant in the app to authorize a folder."

        val folder = resolved.file
        if (!folder.exists() || !folder.isDirectory) {
            return@coroutineScope "❌ Not a folder: ${resolved.displayPath}"
        }

        val allFiles = collectFiles(folder)
        if (allFiles.isEmpty()) return@coroutineScope "📁 Folder is empty: ${resolved.displayPath}"

        val parts = buildParts(allFiles)
        if (parts.isEmpty()) return@coroutineScope "❌ No files small enough to upload from that folder."

        val totalParts = parts.size
        ctx.client.sendMessage(
            ctx.message.chatId,
            "📦 Preparing $totalParts part${if (totalParts == 1) "" else "s"} (no compression, pipelined upload)…"
        )

        var successCount = 0
        var nextZip = async(Dispatchers.IO) {
            createZip(ctx, parts[0], folder, 1, totalParts)
        }

        for (index in parts.indices) {
            val zipFile = try {
                nextZip.await()
            } catch (e: Exception) {
                ctx.client.sendMessage(ctx.message.chatId, "❌ Part ${index + 1} ZIP creation failed: ${e.message}")
                // If this part failed, do not start a dependent upload. Try to prepare the next
                // part independently so a single unreadable file doesn't stop the whole transfer.
                if (index + 1 < totalParts) {
                    nextZip = async(Dispatchers.IO) {
                        createZip(ctx, parts[index + 1], folder, index + 2, totalParts)
                    }
                    continue
                }
                break
            }

            // Start preparing the next part BEFORE uploading this one. This is the key pipeline
            // optimization: ZIP creation and network upload run concurrently.
            if (index + 1 < totalParts) {
                nextZip = async(Dispatchers.IO) {
                    createZip(ctx, parts[index + 1], folder, index + 2, totalParts)
                }
            }

            try {
                ctx.client.sendDocument(
                    ctx.message.chatId,
                    zipFile,
                    caption = if (totalParts > 1) {
                        "${folder.name ?: "folder"} — part ${index + 1} of $totalParts (stored/no compression)"
                    } else {
                        "${folder.name ?: "folder"} (stored/no compression)"
                    }
                )
                successCount++
            } catch (e: TelegramApiException) {
                ctx.client.sendMessage(ctx.message.chatId, "❌ Part ${index + 1} upload failed: ${e.message}")
            } catch (e: Exception) {
                ctx.client.sendMessage(ctx.message.chatId, "❌ Part ${index + 1} upload failed: ${e.message}")
            } finally {
                zipFile.delete()
            }
        }

        if (totalParts > 1) "✅ Sent $successCount of $totalParts parts." else if (successCount == 1) "✅ ZIP sent." else ""
    }

    private data class SourceFile(
        val file: androidx.documentfile.provider.DocumentFile,
        val entryName: String
    )

    private fun collectFiles(root: androidx.documentfile.provider.DocumentFile): List<SourceFile> {
        val result = mutableListOf<SourceFile>()
        fun walk(dir: androidx.documentfile.provider.DocumentFile, prefix: String) {
            dir.listFiles().sortedWith(compareBy({ !it.isDirectory }, { it.name?.lowercase().orEmpty() })).forEach { child ->
                val name = safeName(child.name ?: "file")
                if (child.isDirectory) {
                    walk(child, if (prefix.isEmpty()) name else "$prefix/$name")
                } else if (child.isFile) {
                    result += SourceFile(child, if (prefix.isEmpty()) name else "$prefix/$name")
                }
            }
        }
        walk(root, "")
        return result
    }

    private fun buildParts(files: List<SourceFile>): List<List<SourceFile>> {
        val parts = mutableListOf<MutableList<SourceFile>>()
        var current = mutableListOf<SourceFile>()
        var currentSize = 0L

        for (file in files) {
            val size = file.file.length().coerceAtLeast(0L)
            if (size > maxPartSize) continue
            if (current.isNotEmpty() && currentSize + size > maxPartSize) {
                parts += current
                current = mutableListOf()
                currentSize = 0L
            }
            current += file
            currentSize += size
        }
        if (current.isNotEmpty()) parts += current
        return parts
    }

    private suspend fun createZip(
        ctx: CommandContext,
        files: List<SourceFile>,
        sourceRoot: androidx.documentfile.provider.DocumentFile,
        partNumber: Int,
        totalParts: Int
    ): File = withContext(Dispatchers.IO) {
        val zipFile = File(
            ctx.appContext.cacheDir,
            "${safeName(sourceRoot.name ?: "folder")}_part${partNumber}of${totalParts}_${System.nanoTime()}.zip"
        )
        try {
            ZipOutputStream(zipFile.outputStream().buffered(DEFAULT_BUFFER_SIZE)).use { zos ->
                for (source in files) {
                    val file = source.file
                    val entryName = source.entryName
                    val size = file.length()
                    val crc = calculateCrc32(ctx, file)

                    val entry = ZipEntry(entryName).apply {
                        method = ZipEntry.STORED
                        this.size = size
                        this.crc = crc
                    }
                    zos.putNextEntry(entry)
                    ctx.appContext.contentResolver.openInputStream(file.uri)?.use { input ->
                        input.copyTo(zos, DEFAULT_BUFFER_SIZE)
                    } ?: throw IllegalStateException("Cannot read ${file.name}")
                    zos.closeEntry()
                }
            }
            zipFile
        } catch (e: Exception) {
            zipFile.delete()
            throw e
        }
    }

    private fun calculateCrc32(ctx: CommandContext, file: androidx.documentfile.provider.DocumentFile): Long {
        val crc = CRC32()
        ctx.appContext.contentResolver.openInputStream(file.uri)?.use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val count = input.read(buffer)
                if (count <= 0) break
                crc.update(buffer, 0, count)
            }
        } ?: throw IllegalStateException("Cannot read ${file.name}")
        return crc.value
    }

    private fun safeName(value: String): String = value.replace(Regex("[^A-Za-z0-9._-]"), "_").take(100).ifBlank { "file" }

    companion object {
        private const val DEFAULT_BUFFER_SIZE = 64 * 1024
    }
}
