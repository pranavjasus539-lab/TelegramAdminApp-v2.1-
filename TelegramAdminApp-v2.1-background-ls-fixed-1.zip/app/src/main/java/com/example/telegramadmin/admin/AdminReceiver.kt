package com.example.telegramadmin.admin

import android.app.admin.DeviceAdminReceiver

/**
 * Required boilerplate receiver for Android's Device Admin API. On its own this grants no
 * special power - it only becomes meaningful if you separately provision this app as Device
 * Owner (see README, "Optional: enabling /reboot"), at which point DevicePolicyManager.reboot()
 * becomes callable. Without that provisioning step, /reboot will just explain it's unavailable.
 */
class AdminReceiver : DeviceAdminReceiver()
