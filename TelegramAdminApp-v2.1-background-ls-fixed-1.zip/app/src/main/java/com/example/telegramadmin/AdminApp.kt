package com.example.telegramadmin

import android.app.Application
import com.example.telegramadmin.commands.CommandRegistry
import com.example.telegramadmin.config.ConfigManager
import com.example.telegramadmin.telegram.TelegramClient

class AdminApp : Application() {

    lateinit var configManager: ConfigManager
        private set

    val commandRegistry: CommandRegistry by lazy { CommandRegistry.buildDefault() }

    fun telegramClient(token: String): TelegramClient = TelegramClient(token)

    override fun onCreate() {
        super.onCreate()
        configManager = ConfigManager(this)
    }
}
