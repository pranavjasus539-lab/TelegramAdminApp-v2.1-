package com.example.telegramadmin.util

import android.os.Environment
import java.io.File

/**
 * Resolves paths typed in chat into real files on disk. Requires the "All files access"
 * (MANAGE_EXTERNAL_STORAGE) permission granted from the Settings screen to see anything
 * outside the app's own sandbox - see README.
 */
object FileAccess {

    /** Expands a leading "~" to the shared storage root (e.g. /storage/emulated/0) and resolves
     * relative paths against it, so users can type "~/Download" or "Download/report.pdf". */
    fun resolve(rawPath: String): File {
        val root = Environment.getExternalStorageDirectory()
        val trimmed = rawPath.trim()
        return when {
            trimmed.isEmpty() || trimmed == "~" -> root
            trimmed.startsWith("~/") -> File(root, trimmed.removePrefix("~/"))
            trimmed.startsWith("/") -> File(trimmed)
            else -> File(root, trimmed)
        }.let { File(it.path) } // normalizes any ".." segments via File's own path handling
    }

    fun canAccessAllFiles(): Boolean =
        android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.R ||
            Environment.isExternalStorageManager()
}
