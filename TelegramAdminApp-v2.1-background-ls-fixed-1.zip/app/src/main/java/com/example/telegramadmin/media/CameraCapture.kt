package com.example.telegramadmin.media

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.view.Surface
import java.io.File
import java.io.FileOutputStream

class CameraCapture(private val context: Context) {
    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    @SuppressLint("MissingPermission")
    fun takePhoto(facing: Int, onResult: (Result<File>) -> Unit) {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull { id ->
            manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == facing
        }
        if (cameraId == null) {
            onResult(Result.failure(IllegalStateException("Requested camera is not available")))
            return
        }
        thread = HandlerThread("camera-capture").also { it.start() }
        handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(1280, 720, ImageFormat.JPEG, 1)
        reader!!.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val file = File(context.cacheDir, "capture_${System.currentTimeMillis()}.jpg")
                FileOutputStream(file).use { out -> out.write(image.planes[0].buffer.let { b -> ByteArray(b.remaining()).also { b.get(it) } }) }
                onResult(Result.success(file))
            } catch (e: Exception) {
                onResult(Result.failure(e))
            } finally {
                image.close()
                close()
            }
        }, handler)

        manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
            override fun onOpened(device: CameraDevice) {
                camera = device
                val output = reader!!.surface
                device.createCaptureSession(listOf(output), object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        session = s
                        val request = device.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                            addTarget(output)
                            set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                        }.build()
                        s.capture(request, object : CameraCaptureSession.CaptureCallback() {}, handler)
                    }
                    override fun onConfigureFailed(s: CameraCaptureSession) = onResult(Result.failure(IllegalStateException("Camera setup failed")))
                }, handler)
            }
            override fun onDisconnected(device: CameraDevice) { device.close(); onResult(Result.failure(IllegalStateException("Camera disconnected"))); close() }
            override fun onError(device: CameraDevice, error: Int) { device.close(); onResult(Result.failure(IllegalStateException("Camera error $error"))); close() }
        }, handler)
    }

    fun close() {
        runCatching { session?.close() }
        runCatching { camera?.close() }
        runCatching { reader?.close() }
        thread?.quitSafely()
        session = null; camera = null; reader = null; thread = null; handler = null
    }
}
