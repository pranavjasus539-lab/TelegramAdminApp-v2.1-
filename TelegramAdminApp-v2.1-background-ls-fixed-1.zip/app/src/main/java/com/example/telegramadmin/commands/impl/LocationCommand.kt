package com.example.telegramadmin.commands.impl

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import androidx.core.content.ContextCompat
import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * Single on-demand location fix - deliberately NOT continuous background tracking. Intended
 * use is a one-off "where is my phone right now" check (e.g. after a suspected theft), which is
 * why this requests one fresh fix and stops, rather than subscribing to ongoing updates.
 * Android will show its location-in-use indicator (status bar dot) whenever this runs - that's
 * expected and not suppressed.
 */
class LocationCommand : Command {
    override val name = "location"
    override val description = "Get the phone's current GPS location (one-off lookup, e.g. if lost or stolen)"

    override suspend fun execute(ctx: CommandContext): String {
        val context = ctx.appContext
        val hasFine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!hasFine && !hasCoarse) {
            return "⚠️ Location permission not granted yet. Open the app and tap " +
                "\"Grant location access\", then try again."
        }

        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val provider = when {
            locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> null
        } ?: return "❌ Location is turned off on this phone. Enable Location in system settings, then try again."

        val location = withTimeoutOrNull(20_000) {
            requestSingleLocation(locationManager, provider)
        } ?: lastKnownFallback(locationManager)

        return if (location == null) {
            "❌ Could not get a location fix. Make sure Location is on and try again (works best outdoors)."
        } else {
            val mapsUrl = "https://maps.google.com/?q=${location.latitude},${location.longitude}"
            "📍 Location (±${location.accuracy.toInt()}m accuracy)\n$mapsUrl"
        }
    }

    @SuppressLint("MissingPermission") // permission already verified by caller before this runs
    private suspend fun requestSingleLocation(manager: LocationManager, provider: String): Location? =
        suspendCancellableCoroutine { cont ->
            val listener = object : LocationListener {
                override fun onLocationChanged(loc: Location) {
                    manager.removeUpdates(this)
                    if (cont.isActive) cont.resume(loc)
                }
            }
            try {
                manager.requestSingleUpdate(provider, listener, Looper.getMainLooper())
            } catch (e: SecurityException) {
                if (cont.isActive) cont.resume(null)
            }
            cont.invokeOnCancellation { manager.removeUpdates(listener) }
        }

    @SuppressLint("MissingPermission")
    private fun lastKnownFallback(manager: LocationManager): Location? = try {
        manager.getProviders(true)
            .mapNotNull { manager.getLastKnownLocation(it) }
            .maxByOrNull { it.time }
    } catch (e: SecurityException) {
        null
    }
}
