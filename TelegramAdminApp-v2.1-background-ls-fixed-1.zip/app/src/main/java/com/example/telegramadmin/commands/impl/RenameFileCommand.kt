package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.util.AuthorizedStorage

class RenameFileCommand : Command {
    override val name = "rename"
    override val description = "Rename an authorized file or folder: /rename <path> <new-name>"

    override suspend fun execute(ctx: CommandContext): String {
        val parts = ctx.args.trim().split(Regex("\\s+"), limit = 2)
        if (parts.size != 2) return "Usage: /rename <path> <new-name>"
        val resolved = AuthorizedStorage.resolve(ctx.appContext, parts[0])
            ?: return "❌ Path is not inside a user-authorized storage root."
        val newName = parts[1].trim()
        if (newName.isBlank() || newName == "." || newName == ".." || newName.contains('/') || newName.contains('\\') || newName.contains('\u0000')) return "❌ Invalid new name."
        return if (resolved.file.renameTo(newName)) "✅ Renamed to $newName" else "❌ Rename failed."
    }
}
