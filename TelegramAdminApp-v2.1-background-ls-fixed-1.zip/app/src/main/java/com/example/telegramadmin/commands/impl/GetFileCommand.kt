package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.telegram.TelegramApiException
import com.example.telegramadmin.util.AuthorizedStorage
import java.io.File

class GetFileCommand : Command {
    override val name = "get"
    override val description = "Send an authorized file, e.g. /get /storage/emulated/0/Download/log.txt"

    override suspend fun execute(ctx: CommandContext): String {
        if (ctx.args.isBlank()) return "Usage: /get <path>"
        val resolved = AuthorizedStorage.resolve(ctx.appContext, ctx.args)
            ?: return "❌ File is not inside a user-authorized storage root."
        if (!resolved.file.exists() || !resolved.file.isFile) return "❌ File not found: ${resolved.displayPath}"
        if (resolved.file.length() > 50L * 1024 * 1024) return "❌ File exceeds the 50 MB bot upload limit."
        val temp = File.createTempFile("telegram_get_", ".bin", ctx.appContext.cacheDir)
        return try {
            ctx.appContext.contentResolver.openInputStream(resolved.file.uri)?.use { input -> temp.outputStream().use { input.copyTo(it) } }
                ?: return "❌ Could not read the file."
            ctx.client.sendDocument(ctx.message.chatId, temp, resolved.file.name)
            ""
        } catch (e: TelegramApiException) {
            "❌ Upload failed: ${e.message}"
        } finally { temp.delete() }
    }
}
