package com.example.telegramadmin

import com.example.telegramadmin.commands.CommandRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class CommandRegistryTest {

    @Test
    fun `every built-in command is findable by name`() {
        val registry = CommandRegistry.buildDefault()
        listOf("help", "ping", "status", "ls", "open", "get", "zip", "location", "restart", "stop", "reboot")
            .forEach { name ->
                assertNotNull("Expected /$name to be registered", registry.find(name))
            }
    }

    @Test
    fun `lookup is case-insensitive`() {
        val registry = CommandRegistry.buildDefault()
        assertNotNull(registry.find("STATUS"))
        assertNotNull(registry.find("Status"))
    }

    @Test
    fun `unknown command names return null`() {
        val registry = CommandRegistry.buildDefault()
        assertNull(registry.find("does_not_exist"))
    }

    @Test
    fun `no two commands share a name`() {
        val registry = CommandRegistry.buildDefault()
        val names = registry.all().map { it.name.lowercase() }
        assertEquals("Duplicate command names found", names.size, names.toSet().size)
    }
}
