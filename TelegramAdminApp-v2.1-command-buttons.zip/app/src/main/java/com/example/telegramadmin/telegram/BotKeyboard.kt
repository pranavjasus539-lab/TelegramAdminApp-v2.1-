package com.example.telegramadmin.telegram

import org.json.JSONArray
import org.json.JSONObject

/** Persistent Telegram reply keyboard containing every built-in bot command. */
object BotKeyboard {
    private val rows = listOf(
        listOf("🆘 /help", "🟢 /ping"),
        listOf("📊 /status", "📁 /ls"),
        listOf("📂 /get", "📂 /open"),
        listOf("📱 /apps", "💾 /appstorage"),
        listOf("🗜️ /zip", "🗑️ /delete"),
        listOf("📁 /mkdir", "✏️ /rename"),
        listOf("🔐 /grant", "📍 /location"),
        listOf("🔄 /restart", "⛔ /stop"),
        listOf("🔁 /reboot", "📸 /front"),
        listOf("📸 /back", "🎤 /mic")
    )

    /** Converts the display labels into Telegram ReplyKeyboardMarkup JSON. */
    fun markup(): JSONObject = JSONObject().apply {
        val keyboard = JSONArray()
        rows.forEach { row ->
            val jsonRow = JSONArray()
            row.forEach { label -> jsonRow.put(label) }
            keyboard.put(jsonRow)
        }
        put("keyboard", keyboard)
        put("resize_keyboard", true)
        put("is_persistent", true)
        put("one_time_keyboard", false)
        put("input_field_placeholder", "Choose a command or type one...")
    }

    private val buttonCommands: Map<String, String> = rows
        .flatten()
        .associateWith { label -> label.substring(label.indexOf('/')) }

    /** Converts only one of our exact button labels into its actual command text. */
    fun commandFromButton(text: String): String? = buttonCommands[text]
}
