package com.example.telegramadmin.telegram

import android.util.Log
import com.example.telegramadmin.telegram.model.IncomingMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Minimal, dependency-light Telegram Bot API client using long polling (getUpdates).
 *
 * Long polling was chosen over webhooks because it needs no public endpoint / TLS cert on the
 * phone - it just makes outbound HTTPS calls, which is exactly what a background service on a
 * personal device can reliably do. Per Telegram's docs, `timeout` should be 30-60s in production
 * and the `offset` must be advanced past every update_id you've processed or you'll be re-sent
 * the same updates forever.
 */
class TelegramClient(private val botToken: String) {

    private val baseUrl = "https://api.telegram.org/bot$botToken"
    private val fileBaseUrl = "https://api.telegram.org/file/bot$botToken"

    // Read timeout must comfortably exceed the long-poll timeout we request.
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(POLL_TIMEOUT_SECONDS + 15L, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    /** Call once at startup so a stray webhook (e.g. from earlier testing) doesn't clash - see
     * https://core.telegram.org/bots/api#getupdates: getUpdates returns 409 while a webhook is set. */
    suspend fun deleteWebhook() = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder().url("$baseUrl/deleteWebhook").post(
                "".toRequestBody(null)
            ).build()
            http.newCall(req).execute().use { /* best effort, ignore body */ }
        } catch (e: Exception) {
            Log.w(TAG, "deleteWebhook failed (non-fatal, continuing): ${e.message}")
        }
    }

    /**
     * Long-polls for new updates. Returns an empty list on a normal timeout (no messages) -
     * that's not an error condition. Throws [TelegramApiException] on real failures so the
     * caller's reconnect/backoff loop can react.
     */
    suspend fun getUpdates(offset: Long): List<IncomingMessage> = withContext(Dispatchers.IO) {
        val url = "$baseUrl/getUpdates?timeout=$POLL_TIMEOUT_SECONDS&offset=$offset" +
            "&allowed_updates=%5B%22message%22%5D" // ["message"] url-encoded: skip edits/reactions/etc.
        val req = Request.Builder().url(url).get().build()

        try {
            http.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw TelegramApiException("getUpdates HTTP ${resp.code}: $body")
                }
                val json = JSONObject(body)
                if (!json.optBoolean("ok", false)) {
                    throw TelegramApiException("getUpdates API error: ${json.optString("description")}")
                }
                val results = json.getJSONArray("result")
                buildList {
                    for (i in 0 until results.length()) {
                        IncomingMessage.fromJson(results.getJSONObject(i))?.let { add(it) }
                    }
                }
            }
        } catch (e: TelegramApiException) {
            throw e
        } catch (e: Exception) {
            throw TelegramApiException("getUpdates failed: ${e.message}", e)
        }
    }

    suspend fun sendMessage(chatId: Long, text: String, showCommandKeyboard: Boolean = true) = withContext(Dispatchers.IO) {
        // Telegram messages are capped at 4096 chars; truncate defensively rather than fail.
        val safeText = if (text.length > 4000) text.take(4000) + "\n…(truncated)" else text
        val json = JSONObject().apply {
            put("chat_id", chatId)
            put("text", safeText)
            if (showCommandKeyboard) {
                put("reply_markup", BotKeyboard.markup())
            }
        }
        val req = Request.Builder()
            .url("$baseUrl/sendMessage")
            .post(json.toString().toRequestBody("application/json".toMediaType()))
            .build()
        runCatching {
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    Log.e(TAG, "sendMessage failed: HTTP ${resp.code} ${resp.body?.string()}")
                }
            }
        }.onFailure { Log.e(TAG, "sendMessage threw", it) }
    }

    suspend fun sendDocument(chatId: Long, file: File, caption: String? = null) =
        withContext(Dispatchers.IO) {
            if (!file.exists()) throw TelegramApiException("File does not exist: ${file.absolutePath}")
            // Bot API upload limit for files sent via multipart is 50 MB.
            if (file.length() > 50L * 1024 * 1024) {
                throw TelegramApiException("File is larger than Telegram's 50MB upload limit")
            }
            val mediaType = "application/octet-stream".toMediaType()
            val bodyBuilder = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", chatId.toString())
                .addFormDataPart("document", file.name, file.asRequestBody(mediaType))
            caption?.let { bodyBuilder.addFormDataPart("caption", it) }

            val req = Request.Builder().url("$baseUrl/sendDocument").post(bodyBuilder.build()).build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    throw TelegramApiException("sendDocument HTTP ${resp.code}: ${resp.body?.string()}")
                }
            }
        }

    suspend fun sendPhoto(chatId: Long, file: File, caption: String? = null) =
        withContext(Dispatchers.IO) {
            if (!file.exists()) throw TelegramApiException("Photo does not exist: ${file.absolutePath}")
            val bodyBuilder = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", chatId.toString())
                .addFormDataPart("photo", file.name, file.asRequestBody("image/jpeg".toMediaType()))
            caption?.let { bodyBuilder.addFormDataPart("caption", it) }
            val req = Request.Builder().url("$baseUrl/sendPhoto").post(bodyBuilder.build()).build()
            http.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw TelegramApiException("sendPhoto HTTP ${resp.code}: $body")
                val json = JSONObject(body)
                if (!json.optBoolean("ok", false)) throw TelegramApiException("sendPhoto API error: ${json.optString("description")}")
            }
        }

    suspend fun sendAudio(chatId: Long, file: File, caption: String? = null) =
        withContext(Dispatchers.IO) {
            if (!file.exists()) throw TelegramApiException("Audio does not exist: ${file.absolutePath}")
            if (file.length() > 50L * 1024 * 1024) throw TelegramApiException("Audio is larger than Telegram's upload limit")
            val bodyBuilder = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("chat_id", chatId.toString())
                .addFormDataPart("audio", file.name, file.asRequestBody("audio/mp4".toMediaType()))
            caption?.let { bodyBuilder.addFormDataPart("caption", it) }
            val req = Request.Builder().url("$baseUrl/sendAudio").post(bodyBuilder.build()).build()
            http.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw TelegramApiException("sendAudio HTTP ${resp.code}: $body")
                val json = JSONObject(body)
                if (!json.optBoolean("ok", false)) throw TelegramApiException("sendAudio API error: ${json.optString("description")}")
            }
        }

    /** Resolves a file_id to a temporary download path, per https://core.telegram.org/bots/api#getfile
     * (bots can only fetch files up to 20MB this way). */
    suspend fun getFilePath(fileId: String): String = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$baseUrl/getFile?file_id=$fileId").get().build()
        http.newCall(req).execute().use { resp ->
            val body = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) throw TelegramApiException("getFile HTTP ${resp.code}: $body")
            val json = JSONObject(body)
            if (!json.optBoolean("ok", false)) {
                throw TelegramApiException("getFile API error: ${json.optString("description")}")
            }
            json.getJSONObject("result").getString("file_path")
        }
    }

    suspend fun downloadFile(filePath: String, destination: File) = withContext(Dispatchers.IO) {
        val req = Request.Builder().url("$fileBaseUrl/$filePath").get().build()
        http.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw TelegramApiException("File download HTTP ${resp.code}")
            val body = resp.body ?: throw TelegramApiException("Empty download body")
            destination.parentFile?.mkdirs()
            destination.outputStream().use { out -> body.byteStream().copyTo(out) }
        }
    }

    companion object {
        private const val TAG = "TelegramClient"
        private const val POLL_TIMEOUT_SECONDS = 30
    }
}
