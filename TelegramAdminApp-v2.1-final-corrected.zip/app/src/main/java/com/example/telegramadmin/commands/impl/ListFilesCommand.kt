package com.example.telegramadmin.commands.impl

import com.example.telegramadmin.commands.Command
import com.example.telegramadmin.commands.CommandContext
import com.example.telegramadmin.util.AuthorizedStorage

class ListFilesCommand : Command {
    override val name = "ls"
    override val description = "List an authorized folder, e.g. /ls /storage/emulated/0/Download"

    override suspend fun execute(ctx: CommandContext): String {
        val raw = ctx.args.trim().ifBlank { "/storage/emulated/0" }
        val resolved = AuthorizedStorage.resolve(ctx.appContext, raw)
            ?: return "❌ Folder is not inside a user-authorized storage root.\nUse /grant in the app to authorize a folder."
        if (!resolved.file.exists()) return "❌ Not found: ${resolved.displayPath}"
        if (!resolved.file.isDirectory) return "❌ Not a folder: ${resolved.displayPath}"
        val entries = resolved.file.listFiles().sortedWith(compareBy({ !it.isDirectory }, { it.name?.lowercase().orEmpty() }))
        if (entries.isEmpty()) return "📁 ${resolved.displayPath}\n(empty)"
        return "📁 ${resolved.displayPath}\n" + entries.joinToString("\n") { f ->
            val marker = if (f.isDirectory) "📁" else "📄"
            val size = if (f.isFile) " (${f.length() / 1024} KB)" else ""
            "$marker ${f.name.orEmpty()}$size"
        }
    }
}
